//
//  Post.swift
//  prototype
//
//  Created by Humraj Gill on 2018-11-21.
//  Copyright © 2018 Humraj Gill. All rights reserved.
//

import Foundation
class Post {
    var photoUrl: String
    
    
    init(photoUrlString: String) {
        photoUrl = photoUrlString
    }
}
